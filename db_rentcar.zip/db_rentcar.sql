/*
SQLyog Ultimate v12.4.1 (64 bit)
MySQL - 10.1.34-MariaDB : Database - db_rentcar
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`db_rentcar` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `db_rentcar`;

/*Table structure for table `admin` */

DROP TABLE IF EXISTS `admin`;

CREATE TABLE `admin` (
  `id_admin` char(8) NOT NULL,
  `name_admin` varchar(30) DEFAULT NULL,
  `password` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id_admin`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `admin` */

insert  into `admin`(`id_admin`,`name_admin`,`password`) values 
('A001','sugihpurnama','sugihp14');



/*Table structure for table `car` */

DROP TABLE IF EXISTS `car`;

CREATE TABLE `car` (
  `id_car` char(8) NOT NULL,
  `name_car` varchar(30) DEFAULT NULL,
  `capacity` tinyint(4) DEFAULT NULL,
  `id_admin` char(8) NOT NULL,
  `years` char(4) DEFAULT NULL,
  `image` text,
  `price` char(8) NOT NULL,
  PRIMARY KEY (`id_car`),
  KEY `id_admin` (`id_admin`),
  CONSTRAINT `car_ibfk_1` FOREIGN KEY (`id_admin`) REFERENCES `admin` (`id_admin`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `car` */

insert  into `car`(`id_car`,`name_car`,`capacity`,`id_admin`,`years`,`image`,`price`) values 
('M001','Avanza Black',5,'A001','4','img/14929986845b490164498e1.jpg','400000'),
('M002','Avanza Black',5,'A001','2016','img/10627643885b48fdf46b501.jpg','300000');

/*Table structure for table `users` */

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id_user` char(8) NOT NULL,
  `name_user` char(30) NOT NULL,
  `no_telp` int(11) DEFAULT NULL,
  `password` varchar(30) NOT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `users` */

insert  into `users`(`id_user`,`name_user`,`no_telp`,`password`) values 
('U001','Andri Hadi W',857140707,'');



/*Table structure for table `booking` */

DROP TABLE IF EXISTS `booking`;

CREATE TABLE `booking` (
  `id_booking` char(8) NOT NULL,
  `date` date DEFAULT NULL,
  `id_car` char(8) NOT NULL,
  `id_user` char(8) NOT NULL,
  PRIMARY KEY (`id_booking`),
  KEY `id_car` (`id_car`),
  KEY `id_user` (`id_user`),
  CONSTRAINT `booking_ibfk_1` FOREIGN KEY (`id_car`) REFERENCES `car` (`id_car`),
  CONSTRAINT `booking_ibfk_2` FOREIGN KEY (`id_user`) REFERENCES `users` (`id_user`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `booking` */

insert  into `booking`(`id_booking`,`date`,`id_car`,`id_user`) values 
('B001','2018-07-11','M001','U001');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
